# Tree — Skill Tracker

A single-page web app for tracking learning goals and skill progress in a structured, tree-like roadmap.

## Overview

This project visualizes a set of learning goals as a skill tree. Each node can represent a skill, milestone, or topic, with progress bars, goals, and structured study guidance. It is designed to help you:

- map learning paths by topic
- track progress through skill branches
- keep notes and milestones in one place
- revisit and update learning goals over time

## Files

- `tree.html` — main app and interface
- `README.md` — project documentation

## How to use it

1. Open `tree.html` in a browser.
2. Explore the built-in skill categories and progress tree.
3. Click a skill or goal to view details, guidance, and checkpoints.
4. Update progress as you complete milestones.
5. Use notes and tracking features to keep your learning plan organized.

## Features

- interactive skill tree layout
- goal-based progression tracking
- progress bars for each node
- skill detail panels
- notes and study history support
- onboarding and recommendation flow
- data import/export support for saved state

## Notes

This project is a front-end HTML application with embedded CSS and JavaScript. There is no build step or package install required.

## Local usage

Because it is a static page, you can either:

- open `tree.html` directly in your browser, or
- serve the folder with a local web server if you prefer a browser environment with a URL.

Example:

```bash
python -m http.server 8000
```

Then visit:

```text
http://localhost:8000/tree.html
```

## License

This project does not include a license file. If you plan to share or distribute it, add an appropriate license before publishing.
